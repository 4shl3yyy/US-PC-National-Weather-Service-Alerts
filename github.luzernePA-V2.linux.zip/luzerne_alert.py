import requests
import time
import json
import os
import shutil
import subprocess
import threading
import pyttsx3
from datetime import datetime
import tkinter as tk
from tkinter import scrolledtext

print("Luzerne County Weather Alert Monitor STARTED")

# ================= CONFIG =================
CHECK_INTERVAL = 300    # 5 minutes
ALERT_SOUND = "alert.wav"
LOG_FILE = "weather_alert.log"
SEEN_ALERTS_FILE = "seen_alerts.json"

# Only use the county zone — no forecast zone.
NWS_ZONES = ["PAC079"]
NWS_API_TEMPLATE = "https://api.weather.gov/alerts/active/zone/{zone}"

# Luzerne County FIPS code (42=PA, 079=Luzerne)
LUZERNE_FIPS = "42079"

HEADERS = {
    "User-Agent": "LuzerneWeatherAlert/1.0 (contact: local-monitor)",
    "Accept": "application/geo+json",
}
# =========================================


_tts_engine = None

def get_tts():
    global _tts_engine
    if _tts_engine is None:
        _tts_engine = pyttsx3.init()
    return _tts_engine


def play_sound(path):
    """Play audio without playsound. Tries paplay -> ffplay -> aplay."""
    candidates = []
    if path.lower().endswith(".wav"):
        if shutil.which("paplay"):
            candidates.append(["paplay", path])
        if shutil.which("aplay"):
            candidates.append(["aplay", "-q", path])
    if shutil.which("ffplay"):
        candidates.append(
            ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", path]
        )
    if not candidates:
        log("No audio player found (install ffmpeg or pipewire-utils)")
        return False
    try:
        subprocess.run(candidates[0], check=False)
        return True
    except Exception as e:
        log(f"Audio playback failed: {e}")
        return False


def speak(text):
    try:
        engine = get_tts()
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        log(f"TTS failed: {e}")


def show_popup(title, message):
    """Run Tk popup in a background thread so the monitor keeps polling."""
    def _run():
        root = tk.Tk()
        root.title(title)
        root.geometry("700x500")
        root.attributes("-topmost", True)

        text_area = scrolledtext.ScrolledText(
            root, wrap=tk.WORD, font=("DejaVu Sans", 10)
        )
        text_area.pack(expand=True, fill="both", padx=10, pady=10)
        text_area.insert(tk.END, message)
        text_area.configure(state="disabled")

        tk.Button(root, text="OK", command=root.destroy).pack(pady=8)
        root.mainloop()

    t = threading.Thread(target=_run, daemon=True)
    t.start()


def log(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {message}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def load_seen_alerts():
    if os.path.exists(SEEN_ALERTS_FILE):
        try:
            with open(SEEN_ALERTS_FILE, "r") as f:
                return set(json.load(f))
        except Exception:
            return set()
    return set()


def save_seen_alerts(alert_ids):
    with open(SEEN_ALERTS_FILE, "w") as f:
        json.dump(list(alert_ids), f)


def check_alerts(seen_alerts):
    log("Checking for active alerts...")

    features = []
    for zone in NWS_ZONES:
        url = NWS_API_TEMPLATE.format(zone=zone)
        try:
            response = requests.get(url, headers=HEADERS, timeout=15)
            response.raise_for_status()
            features.extend(response.json().get("features", []))
        except Exception as e:
            log(f"ERROR fetching alerts for {zone}: {e}")

    # De-dupe by alert ID
    unique = {}
    for feat in features:
        fid = feat.get("id")
        if fid:
            unique[fid] = feat
    alerts = list(unique.values())

    log(f"Found {len(alerts)} active alerts in zone PAC079")

    for alert in alerts:
        alert_id = alert.get("id")
        if not alert_id or alert_id in seen_alerts:
            continue

        props = alert["properties"]

        # --- Filter: confirm the alert actually covers Luzerne County ---
        geocodes = props.get("geocode", {}) or {}
        ugc_geocodes = geocodes.get("UGC", []) or []
        fips_geocodes = geocodes.get("FIPS", []) or []
        area_desc = str(props.get("areaDesc", ""))

        haystack = " ".join([
            " ".join(ugc_geocodes),
            " ".join(fips_geocodes),
            area_desc,
        ]).lower()

        is_luzerne = (
            "pac079" in haystack
            or LUZERNE_FIPS in haystack
            or "luzerne" in haystack
        )

        if not is_luzerne:
            log(f"Skipping alert {alert_id} — does not cover Luzerne County")
            continue

        event = props.get("event", "Unknown Alert")
        headline = props.get("headline", "No headline")
        description = props.get("description", "No description")
        instruction = props.get("instruction", "No instructions")
        severity = props.get("severity", "Unknown")
        certainty = props.get("certainty", "Unknown")
        urgency = props.get("urgency", "Unknown")
        sender = props.get("senderName", "Unknown Sender")

        full_text = (
            f"Event: {event}\n"
            f"Severity: {severity}\n"
            f"Urgency: {urgency}\n"
            f"Certainty: {certainty}\n"
            f"Issued By: {sender}\n\n"
            f"Headline:\n{headline}\n\n"
            f"Description:\n{description}\n\n"
            f"Instructions:\n{instruction}"
        )

        log(f"NEW ALERT: {event}")
        log(headline)

        if os.path.exists(ALERT_SOUND):
            play_sound(ALERT_SOUND)
        else:
            log(f"{ALERT_SOUND} not found")

        speak(f"Weather alert for Luzerne County. {event}. {headline}")
        show_popup(f"Weather Alert – {event}", full_text)

        seen_alerts.add(alert_id)
        save_seen_alerts(seen_alerts)

    return seen_alerts


def main():
    log("Program initialized")
    seen_alerts = load_seen_alerts()
    while True:
        seen_alerts = check_alerts(seen_alerts)
        time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    main()
